<?php

namespace App\Shop\OrderStatuses\Exceptions;

use Doctrine\Instantiator\Exception\InvalidArgumentException;

class OrderStatusInvalidArgumentException extends InvalidArgumentException
{
}
