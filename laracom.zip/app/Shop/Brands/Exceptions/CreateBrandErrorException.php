<?php

namespace App\Shop\Brands\Exceptions;

class CreateBrandErrorException extends \Exception
{
}
