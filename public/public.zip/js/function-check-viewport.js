'use strict';
var $window = $(window);
function viewPortWidth() {
  var viewPortWidth = $window.width();
  return viewPortWidth;
}

function viewPortHeight() {
  var viewPortHeight = $window.height();
  return viewPortHeight;
}
